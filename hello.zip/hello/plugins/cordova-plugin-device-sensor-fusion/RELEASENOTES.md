# Release Notes

### 0.0.3 (2015-09-06)
  * FusionResult extended (see 'Properties') !!!ATTENTION: DEPRECATION!!!

### 0.0.2
  * README.md updated

### 0.0.1
  * initial commit
  