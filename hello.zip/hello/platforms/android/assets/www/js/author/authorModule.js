angular.module('author',[])

.run([function(){

}])

.config([function(){

}])
