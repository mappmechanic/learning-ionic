angular.module('accelerometer',[])

.run([function(){

}])

.config([function(){

}])
