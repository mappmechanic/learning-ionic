angular.module('map',[])

.run([function(){

}])

.config([function(){

}])
